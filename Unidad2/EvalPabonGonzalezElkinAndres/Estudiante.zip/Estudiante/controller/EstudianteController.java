// Autor: Elkin Andres
// Fecha: 3 de julio de 2025
// Descripción: Esta clase actúa como el controlador para gestionar las operaciones relacionadas con los estudiantes
//              Utiliza el DAO para realizar las operaciones de creación, lectura, actualización y eliminación

package controller;

import dao.EstudianteDAO;
import java.util.List;
import model.Estudiante;

public class EstudianteController {
    // Instancia del DAO para interactuar con los datos de los estudiantes
    private final EstudianteDAO dao = new EstudianteDAO();

    /**
     * Método para crear un nuevo estudiante y agregarlo a la lista
     * @param id Identificador único del estudiante
     * @param apellidos Apellidos del estudiante
     * @param nombres Nombres del estudiante
     * @param edad Edad del estudiante
     */
    public void crearEstudiante(int id, String apellidos, String nombres, int edad) {
        Estudiante e = new Estudiante(id, apellidos, nombres, edad);
        dao.agregar(e);
    }

    /**
     * Método para obtener la lista de todos los estudiantes almacenados
     * @return Lista de objetos Estudiante
     */
    public List<Estudiante> obtenerTodos() {
        return dao.listar();
    }

    /**
     * Método para buscar un estudiante por su identificador único
     * @param id Identificador del estudiante que se desea buscar
     * @return El objeto Estudiante si se encuentra, o null si no existe
     */
    public Estudiante buscarEstudiante(int id) {
        return dao.buscarPorId(id);
    }

    /**
     * Método para actualizar la información de un estudiante existente
     * @param id Identificador único del estudiante
     * @param apellidos Nuevos apellidos del estudiante
     * @param nombres Nuevos nombres del estudiante
     * @param edad Nueva edad del estudiante
     * @return true si la actualización fue exitosa, false si no se encontró el estudiante
     */
    public boolean actualizarEstudiante(int id, String apellidos, String nombres, int edad) {
        Estudiante actualizado = new Estudiante(id, apellidos, nombres, edad);
        return dao.actualizar(actualizado);
    }

    /**
     * Método para eliminar un estudiante por su identificador único
     * @param id Identificador del estudiante que se desea eliminar
     * @return true si el estudiante fue eliminado, false si no se encontró
     */
    public boolean eliminarEstudiante(int id) {
        return dao.eliminar(id);
    }
}
// Autor: Elkin Andres
// Fecha: 3 de julio de 2025
// Descripción: Esta clase implementa la interfaz gráfica de usuario (UI) para gestionar estudiantes utilizando el patrón MVC.
//              Permite realizar operaciones CRUD (Crear, Leer, Actualizar, Eliminar) sobre los estudiantes.

package ui;

import controller.EstudianteController;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import model.Estudiante;

public class Main extends JFrame {
    // Controlador para interactuar con los datos de los estudiantes.
    private EstudianteController controller = new EstudianteController();
    private JTable table;
    private DefaultTableModel model;

    // Campos de texto para ingresar los datos
    private JTextField idField = new JTextField(5);
    private JTextField apellidosField = new JTextField(10);
    private JTextField nombresField = new JTextField(10);
    private JTextField edadField = new JTextField(5);

    public Main() {
        setTitle("CRUD Estudiantes - MVC");
        setSize(600, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        // tabla
        model = new DefaultTableModel(new String[]{"ID", "Apellidos", "Nombres", "Edad"}, 0);
        table = new JTable(model);
        JScrollPane scroll = new JScrollPane(table);

        JPanel formPanel = new JPanel(new GridLayout(2, 5));
        formPanel.add(new JLabel("ID"));
        formPanel.add(new JLabel("Apellidos"));
        formPanel.add(new JLabel("Nombres"));
        formPanel.add(new JLabel("Edad"));
        formPanel.add(new JLabel(""));

        formPanel.add(idField);
        formPanel.add(apellidosField);
        formPanel.add(nombresField);
        formPanel.add(edadField);

        JButton addButton = new JButton("Agregar");
        JButton updateButton = new JButton("Actualizar");
        JButton deleteButton = new JButton("Eliminar");
        JButton clearButton = new JButton("Limpiar");

        formPanel.add(addButton);

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(clearButton);

        add(scroll, BorderLayout.CENTER);
        add(formPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.SOUTH);

        addButton.addActionListener(_ -> {
            // Agrega un nuevo estudiante utilizando los datos ingresados
            int id = Integer.parseInt(idField.getText());
            String apellidos = apellidosField.getText();
            String nombres = nombresField.getText();
            int edad = Integer.parseInt(edadField.getText());
            controller.crearEstudiante(id, apellidos, nombres, edad);
            actualizarTabla();
            limpiarCampos();
        });

        updateButton.addActionListener(_ -> {
            // Actualiza un estudiante existente con los datos ingresados
            int id = Integer.parseInt(idField.getText());
            String apellidos = apellidosField.getText();
            String nombres = nombresField.getText();
            int edad = Integer.parseInt(edadField.getText());
            boolean actualizado = controller.actualizarEstudiante(id, apellidos, nombres, edad);
            if (actualizado) {
                actualizarTabla();
                limpiarCampos();
            } else {
                JOptionPane.showMessageDialog(this, "ID no encontrado.");
            }
        });

        deleteButton.addActionListener(_ -> {
            // Elimina un estudiante por su identificador único
            int id = Integer.parseInt(idField.getText());
            boolean eliminado = controller.eliminarEstudiante(id);
            if (eliminado) {
                actualizarTabla();
                limpiarCampos();
            } else {
                JOptionPane.showMessageDialog(this, "ID no encontrado.");
            }
        });

        clearButton.addActionListener(_ -> limpiarCampos());

        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                // Llena los campos de entrada con los datos del estudiante seleccionado en la tabla
                int fila = table.getSelectedRow();
                idField.setText(model.getValueAt(fila, 0).toString());
                apellidosField.setText(model.getValueAt(fila, 1).toString());
                nombresField.setText(model.getValueAt(fila, 2).toString());
                edadField.setText(model.getValueAt(fila, 3).toString());
            }
        });

        // Actualiza la tabla con los datos actuales
        actualizarTabla();
    }

    /**
     * Método para actualizar la tabla con los datos de los estudiantes
     */
    private void actualizarTabla() {
        model.setRowCount(0);
        for (Estudiante e : controller.obtenerTodos()) {
            model.addRow(new Object[]{e.getId(), e.getApellidos(), e.getNombres(), e.getEdad()});
        }
    }

    /**
     * Método para limpiar los campos de entrada
     */
    private void limpiarCampos() {
        idField.setText("");
        apellidosField.setText("");
        nombresField.setText("");
        edadField.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Main().setVisible(true));
    }
}
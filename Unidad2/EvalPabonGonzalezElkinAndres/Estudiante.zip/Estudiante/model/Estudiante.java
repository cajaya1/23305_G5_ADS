// Autor: Elkin Andres
// Fecha: 3 de julio de 2025
// Descripción: Esta clase representa un modelo de estudiante con atributos básicos como id, apellidos, nombres y edad
//              Incluye métodos para acceder y modificar estos atributos (getters y setters)

package model;

public class Estudiante {
    // identificador unico del estudiante
    private int id;

    // apellidos del estudiante
    private String apellidos;

    // nombres del estudiante
    private String nombres;

    // edad del estudiante
    private int edad;

    /**
     * Constructor de la clase Estudiante.
     * Inicializa los atributos con los valores proporcionados
     * @param id Identificador único del estudiante
     * @param apellidos Apellidos del estudiante
     * @param nombres Nombres del estudiante
     * @param edad Edad del estudiante
     */
    public Estudiante(int id, String apellidos, String nombres, int edad) {
        this.id = id;
        this.apellidos = apellidos;
        this.nombres = nombres;
        this.edad = edad;
    }

    /**
     * Método para obtener el identificador único del estudiante
     * @return id del estudiante
     */
    public int getId() { return id; }

    /**
     * Método para establecer el identificador único del estudiante
     * @param id Nuevo identificador del estudiante
     */
    public void setId(int id) { this.id = id; }

    /**
     * Método para obtener los apellidos del estudiante
     * @return Apellidos del estudiante
     */
    public String getApellidos() { return apellidos; }

    /**
     * Método para establecer los apellidos del estudiante
     * @param apellidos Nuevos apellidos del estudiante
     */
    public void setApellidos(String apellidos) { this.apellidos = apellidos; }

    /**
     * Método para obtener los nombres del estudiante
     * @return Nombres del estudiante
     */
    public String getNombres() { return nombres; }

    /**
     * Método para establecer los nombres del estudiante
     * @param nombres Nuevos nombres del estudiante
     */
    public void setNombres(String nombres) { this.nombres = nombres; }

    /**
     * Método para obtener la edad del estudiante
     * @return Edad del estudiante
     */
    public int getEdad() { return edad; }

    /**
     * Método para establecer la edad del estudiante
     * @param edad Nueva edad del estudiante
     */
    public void setEdad(int edad) { this.edad = edad; }
}
// Autor: Elkin Andres
// Fecha: 3 de julio de 2025
// Descripción: Esta clase implementa un dao para gestionar objetos de tipo Estudiante.
//              Proporciona métodos para agregar, listar, buscar, actualizar y eliminar estudiantes en una lista interna.

package dao;

import java.util.ArrayList;
import java.util.List;
import model.Estudiante;

public class EstudianteDAO {
    // Lista que almacena los objetos de tipo Estudiante
    private final List<Estudiante> estudiantes = new ArrayList<>();

    /**
     * Método para agregar un nuevo estudiante a la lista
     * @param e Objeto de tipo Estudiante que se desea agregar
     */
    public void agregar(Estudiante e) {
        estudiantes.add(e);
    }

    /**
     * Método para listar todos los estudiantes almacenados
     * @return Lista de objetos Estudiante
     */
    public List<Estudiante> listar() {
        return estudiantes;
    }

    /**
     * Método para buscar un estudiante por su identificador único
     * @param id Identificador del estudiante que se desea buscar
     * @return El objeto Estudiante si se encuentra, o null si no existe
     */
    public Estudiante buscarPorId(int id) {
        for (Estudiante e : estudiantes) {
            if (e.getId() == id) return e;
        }
        return null;
    }

    /**
     * Método para actualizar la información de un estudiante existente
     * @param actualizado Objeto Estudiante con los datos actualizados
     * @return true si la actualización fue exitosa, false si no se encontró el estudiante
     */
    public boolean actualizar(Estudiante actualizado) {
        for (int i = 0; i < estudiantes.size(); i++) {
            if (estudiantes.get(i).getId() == actualizado.getId()) {
                estudiantes.set(i, actualizado);
                return true;
            }
        }
        return false;
    }

    /**
     * Método para eliminar un estudiante de la lista por su identificador único
     * @param id Identificador del estudiante que se desea eliminar
     * @return true si el estudiante fue eliminado, false si no se encontró
     */
    public boolean eliminar(int id) {
        return estudiantes.removeIf(e -> e.getId() == id);
    }
}
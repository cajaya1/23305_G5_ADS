package ec.edu.espe.ui;

import ec.edu.espe.controller.EstudianteController;
import ec.edu.espe.model.Estudiante;
import java.util.Scanner;

public class Menu {
    private Scanner scanner;
    private EstudianteController controller;

    // Constructor que inicializa el lector de datos y el controlador
    public Menu() {
        this.scanner = new Scanner(System.in);
        this.controller = new EstudianteController();
    }

    // Método principal que ejecuta el flujo del menú de opciones
    public void ejecutar() {
        int opcion;

        do {
            mostrarMenu(); // Muestra las alternativas disponibles
            opcion = scanner.nextInt(); // Captura la elección del usuario
            scanner.nextLine(); // Limpia el búfer del scanner para evitar saltos

            switch (opcion) {
                case 1:
                    crearEstudiante(); // Llama a la función para registrar un nuevo estudiante
                    break;
                case 2:
                    listarEstudiantes(); // Muestra el listado completo de estudiantes
                    break;
                case 3:
                    buscarEstudiante(); // Permite consultar un estudiante por su ID
                    break;
                case 4:
                    actualizarEstudiante(); // Edita los datos de un estudiante ya creado
                    break;
                case 5:
                    eliminarEstudiante(); // Elimina un estudiante mediante su ID
                    break;
                case 6:
                    System.out.println("\n¡Hasta Pronto!"); // Mensaje de salida
                    break;
                default:
                    System.out.println("\nOpción inválida. Intente de nuevo."); // Alerta por selección errónea
            }
        } while (opcion != 6); // Repite hasta que el usuario elija salir

        scanner.close(); // Cierra el lector de entrada
    }

    // Presenta el menú con las funciones disponibles al usuario
    private void mostrarMenu() {
        System.out.println("\n=== SISTEMA DE GESTIÓN DE ESTUDIANTES ===");
        System.out.println("1. Crear estudiante");
        System.out.println("2. Listar todos los estudiantes");
        System.out.println("3. Buscar estudiante por ID");
        System.out.println("4. Actualizar estudiante");
        System.out.println("5. Eliminar estudiante");
        System.out.println("6. Salir");
        System.out.print("Seleccione una opción: ");
    }

    // Solicita datos y registra un nuevo estudiante
    private void crearEstudiante() {
        System.out.println("\n--- CREAR ESTUDIANTE ---");
        System.out.print("Apellidos: ");
        String apellidos = scanner.nextLine();
        System.out.print("Nombres: ");
        String nombres = scanner.nextLine();
        System.out.print("Edad: ");
        int edad = scanner.nextInt();

        int nuevoId = controller.crearEstudiante(apellidos, nombres, edad);
        System.out.println("\nEstudiante  fue creado exitosamente con ID: " + nuevoId);
    }

    // Imprime todos los estudiantes registrados
    private void listarEstudiantes() {
        System.out.println("\n--- LISTA DE ESTUDIANTES ---");
        for (Estudiante estudiante : controller.obtenerTodosEstudiantes()) {
            System.out.println("ID: " + estudiante.getId() +
                    " | Apellidos: " + estudiante.getApellidos() +
                    " | Nombres: " + estudiante.getNombres() +
                    " | Edad: " + estudiante.getEdad());
        }
        if (controller.obtenerTodosEstudiantes().isEmpty()) {
            System.out.println("No hay estudiantes registrados."); // Mensaje cuando no hay datos
        }
    }

    // Busca un estudiante utilizando su identificador
    private void buscarEstudiante() {
        System.out.println("\n--- BUSCAR ESTUDIANTE ---");
        System.out.print("Ingrese el ID del estudiante: ");
        int id = scanner.nextInt();

        Estudiante estudiante = controller.buscarEstudiantePorId(id);
        if (estudiante != null) {
            System.out.println("\nEstudiante encontrado:");
            System.out.println("ID: " + estudiante.getId() +
                    " | Apellidos: " + estudiante.getApellidos() +
                    " | Nombres: " + estudiante.getNombres() +
                    " | Edad: " + estudiante.getEdad());
        } else {
            System.out.println("\nNo se encontró al estudiante con ID: " + id); // Si no se halla el estudiante
        }
    }

    // Permite modificar la información de un estudiante existente
    private void actualizarEstudiante() {
        System.out.println("\n--- ACTUALIZAR ESTUDIANTE ---");
        System.out.print("ID del estudiante a actualizar: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Limpieza del buffer

        if (controller.buscarEstudiantePorId(id) != null) {
            System.out.print("Nuevos apellidos: ");
            String apellidos = scanner.nextLine();
            System.out.print("Nuevos nombres: ");
            String nombres = scanner.nextLine();
            System.out.print("Nueva edad: ");
            int edad = scanner.nextInt();

            boolean actualizado = controller.actualizarEstudiante(id, apellidos, nombres, edad);
            if (actualizado) {
                System.out.println("\nEstudiante actualizado exitosamente."); // Confirmación de éxito
            } else {
                System.out.println("\nError al actualizar el estudiante."); // En caso de fallo
            }
        } else {
            System.out.println("\nNo se encontró estudiante con ID: " + id); // ID no encontrado
        }
    }

    // Elimina un estudiante mediante su ID
    private void eliminarEstudiante() {
        System.out.println("\n--- ELIMINAR ESTUDIANTE ---");
        System.out.print("ID del estudiante a eliminar: ");
        int id = scanner.nextInt();

        boolean eliminado = controller.eliminarEstudiantePorId(id);
        if (eliminado) {
            System.out.println("\nEstudiante eliminado."); // Confirmación de borrado
        } else {
            System.out.println("\nNo se encontró estudiante con ID: " + id); // No se encontró el ID
        }
    }
}

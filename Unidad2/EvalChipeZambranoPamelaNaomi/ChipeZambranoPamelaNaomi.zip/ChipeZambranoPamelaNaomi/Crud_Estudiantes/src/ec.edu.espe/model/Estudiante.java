package ec.edu.espe.model;

// Clase que representa a un estudiante
public class Estudiante {
    // Atributos privados del estudiante
    private int id;
    private String apellidos;
    private String nombres;
    private int edad;

    // Constructor que inicializa todos los atributos del estudiante
    public Estudiante(int id, String apellidos, String nombres, int edad) {
        this.id = id;
        this.apellidos = apellidos;
        this.nombres = nombres;
        this.edad = edad;
    }

    // Métodos getter y setter para el atributo 'id'
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    // Métodos getter y setter para el atributo 'apellidos'
    public String getApellidos() { return apellidos; }
    public void setApellidos(String apellidos) { this.apellidos = apellidos; }

    // Métodos getter y setter para el atributo 'nombres'
    public String getNombres() { return nombres; }
    public void setNombres(String nombres) { this.nombres = nombres; }

    // Métodos getter y setter para el atributo 'edad'
    public int getEdad() { return edad; }
    public void setEdad(int edad) { this.edad = edad; }
}

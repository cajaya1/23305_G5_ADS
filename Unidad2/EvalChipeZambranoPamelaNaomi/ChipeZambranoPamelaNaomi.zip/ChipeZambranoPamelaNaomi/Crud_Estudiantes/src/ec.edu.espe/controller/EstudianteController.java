package ec.edu.espe.controller;

import ec.edu.espe.dao.EstudianteDAO;
import ec.edu.espe.model.Estudiante;
import java.util.List;

public class EstudianteController {
    private EstudianteDAO estudianteDAO;

    /**
     * Constructor del controlador de estudiantes
     */
    public EstudianteController() {
        this.estudianteDAO = new EstudianteDAO();
    }

    /**
     * Crear estudiante
     * @param apellidos
     * @param nombres
     * @param edad
     * @return estudiante creado
     */
    public int crearEstudiante(String apellidos, String nombres, int edad) {
        return estudianteDAO.agregar(apellidos, nombres, edad);
    }

    /**
     * Obtener todos los estudiantes
     * @return lista de estudiantes
     */
    public List<Estudiante> obtenerTodosEstudiantes() {
        return estudianteDAO.listar();
    }

    /**
     * Buscar estudiante por ID
     * @param id
     * @return estudiante encontrado o null si no existe
     */
    public Estudiante buscarEstudiantePorId(int id) {
        return estudianteDAO.buscarPorId(id);
    }

    /**
     * Actualizar estudiante
     * @param id
     * @param apellidos
     * @param nombres
     * @param edad
     * @return true si se actualizó correctamente, false si no se encontró el estudiante
     */
    public boolean actualizarEstudiante(int id, String apellidos, String nombres, int edad) {
        Estudiante estudiante = new Estudiante(id, apellidos, nombres, edad);
        return estudianteDAO.actualizarEstudiante(estudiante);
    }

    /**
     * Eliminar al estudiante por ID
     * @param id
     * @return true si se eliminó correctamente, false si no se encontró el estudiante
     */
    public boolean eliminarEstudiantePorId(int id) {
        return estudianteDAO.eliminarEstudiantePorId(id);
    }

}

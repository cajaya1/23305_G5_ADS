package ec.edu.espe.dao;

import java.util.ArrayList;
import java.util.List;
import ec.edu.espe.model.Estudiante;

public class EstudianteDAO {
    private List<Estudiante> estudiantes = new ArrayList<>();
    private int proximoId = 1;

    /**
     * Constructor de la clase EstudianteDAO
     * Inicia la colección de estudiantes con algunos registros de ejemplo
     */
    public EstudianteDAO() {
        cargarDatosIniciales();
    }

    /**
     * Inserta datos base de estudiantes
     * Este procedimiento se invoca en el constructor para insertar ejemplos preestablecidos
     */
    private void cargarDatosIniciales() {
        agregarEstudiante(new Estudiante(obtenerProximoId(), "Orquera Revelo", "Francis Xavier", 23));
        agregarEstudiante(new Estudiante(obtenerProximoId(), "Mora Marcillo", "Paul Jhordy", 22));
        agregarEstudiante(new Estudiante(obtenerProximoId(), "Mocha Gonzalo", "Orly Alvarado", 62));
        agregarEstudiante(new Estudiante(obtenerProximoId(), "Zambrano Chila", "Virginia Viviana", 40));
        agregarEstudiante(new Estudiante(obtenerProximoId(), "Orquera Chipe", "Olivia Eduarda", 0));
    }

    /**
     * Genera el ID siguiente para un nuevo estudiante
     * @return el ID disponible para asignar
     */
    private int obtenerProximoId() {
        return proximoId++;
    }

    /**
     * Inserta un nuevo estudiante en la lista
     * @param estudiante objeto que se desea almacenar
     * @return verdadero si se insertó correctamente, falso si es nulo
     */
    public boolean agregarEstudiante(Estudiante estudiante) {
        if (estudiante != null) {
            return estudiantes.add(estudiante);
        }
        return false;
    }

    // Inserta estudiante con ID generado automáticamente
    public int agregar(String apellidos, String nombres, int edad) {
        int nuevoId = obtenerProximoId();
        Estudiante estudiante = new Estudiante(nuevoId, apellidos, nombres, edad);
        estudiantes.add(estudiante);
        return nuevoId;
    }

    /**
     * Devuelve la lista completa de estudiantes
     * @return colección de todos los estudiantes almacenados
     */
    public List<Estudiante> listar() {
        return new ArrayList<>(estudiantes);
    }

    /**
     * Localiza un estudiante mediante su ID
     * @param id identificador del estudiante buscado
     * @return instancia del estudiante si existe, de lo contrario null
     */
    public Estudiante buscarPorId(int id) {
        for (Estudiante estudiante : estudiantes) {
            if (estudiante.getId() == id) {
                return estudiante;
            }
        }
        return null;
    }

    /**
     * Modifica los datos de un estudiante ya existente
     * @param estudianteActualizado objeto con los datos modificados
     * @return true si la modificación fue exitosa, false si no se encontró coincidencia
     */
    public boolean actualizarEstudiante(Estudiante estudianteActualizado) {
        for (int i = 0; i < estudiantes.size(); i++) {
            if (estudiantes.get(i).getId() == estudianteActualizado.getId()) {
                estudiantes.set(i, estudianteActualizado);
                return true;
            }
        }
        return false;
    }

    /**
     * Suprime un estudiante utilizando su ID
     * @param id identificador del estudiante que se desea eliminar
     * @return true si se eliminó con éxito, false si no se localizó el estudiante
     */
    public boolean eliminarEstudiantePorId(int id) {
        return estudiantes.removeIf(estudiante -> estudiante.getId() == id);
    }
}

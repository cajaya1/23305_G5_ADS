package ec.edu.espe.logica_negocio;

import ec.edu.espe.datos.model.Estudiante;
import ec.edu.espe.datos.repository.EstudianteRepository;

import java.util.List;

/**
 * Clase de servicio que encapsula la lógica de negocio relacionada con los estudiantes.
 * Utiliza el repositorio para acceder y modificar los datos.
 */
public class EstudianteService {
    private final EstudianteRepository estudianteRepository;

    /**
     * Constructor que inicializa el repositorio de estudiantes.
     */
    public EstudianteService() {
        this.estudianteRepository = new EstudianteRepository();
    }

    /**
     * Crea un nuevo estudiante y lo guarda en el repositorio.
     * @param id ID del estudiante.
     * @param nombre Nombre del estudiante.
     * @param edad Edad del estudiante.
     */
    public void crearEstudiante(int id, String nombre, int edad) {
        Estudiante nuevo = new Estudiante(id, nombre, edad);
        estudianteRepository.guardar(nuevo);
    }

    /**
     * Retorna todos los estudiantes ordenados por ID.
     * @return Lista de estudiantes.
     */
    public List<Estudiante> obtenerTodos() {
        return estudianteRepository.obtenerTodos();
    }

    /**
     * Busca un estudiante por su ID.
     * @param id ID del estudiante.
     * @return El estudiante encontrado o null si no existe.
     */
    public Estudiante buscarPorId(int id) {
        return estudianteRepository.buscarPorId(id).orElse(null);
    }

    /**
     * Actualiza los datos de un estudiante.
     * @param id ID del estudiante.
     * @param nuevoNombre Nuevo nombre del estudiante.
     * @param nuevaEdad Nueva edad del estudiante.
     */
    public void actualizarEstudiante(int id, String nuevoNombre, int nuevaEdad) {
        Estudiante actualizado = new Estudiante(id, nuevoNombre, nuevaEdad);
        estudianteRepository.actualizar(actualizado);
    }

    /**
     * Elimina un estudiante del repositorio por su ID.
     * @param id ID del estudiante.
     */
    public void eliminarEstudiante(int id) {
        estudianteRepository.eliminarPorId(id);
    }
}

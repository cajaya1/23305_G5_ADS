package ec.edu.espe;

import ec.edu.espe.presentacion.EstudianteUI;

import javax.swing.*;

/**
 * Clase principal que inicia la aplicación de gestión de estudiantes.
 */
public class Main {
    /**
     * Método main que lanza la interfaz gráfica.
     * @param args Argumentos de línea de comandos.
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            EstudianteUI ventana = new EstudianteUI();
            ventana.setVisible(true);
        });
    }
}

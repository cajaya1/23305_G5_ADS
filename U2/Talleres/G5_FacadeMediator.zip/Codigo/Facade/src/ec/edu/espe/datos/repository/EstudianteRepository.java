package ec.edu.espe.datos.repository;

import ec.edu.espe.datos.model.Estudiante;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

/**
 * Clase que simula un repositorio en memoria para almacenar estudiantes.
 * Permite realizar operaciones CRUD sobre la lista de estudiantes.
 */
public class EstudianteRepository {
    private final List<Estudiante> estudiantes = new ArrayList<>();

    /**
     * Guarda un nuevo estudiante en la lista.
     * @param estudiante Objeto Estudiante a guardar.
     */
    public void guardar(Estudiante estudiante) {
        estudiantes.add(estudiante);
    }

    /**
     * Retorna todos los estudiantes ordenados por ID ascendente.
     * @return Lista ordenada de estudiantes.
     */
    public List<Estudiante> obtenerTodos() {
        return estudiantes.stream()
                .sorted(Comparator.comparingInt(Estudiante::getId))
                .toList();
    }

    /**
     * Busca un estudiante por su ID.
     * @param id Identificador del estudiante a buscar.
     * @return Optional con el estudiante si se encuentra.
     */
    public Optional<Estudiante> buscarPorId(int id) {
        return estudiantes.stream()
                .filter(e -> e.getId() == id)
                .findFirst();
    }

    /**
     * Actualiza los datos de un estudiante existente.
     * @param estudianteActualizado Objeto con los nuevos datos.
     */
    public void actualizar(Estudiante estudianteActualizado) {
        buscarPorId(estudianteActualizado.getId()).ifPresent(estudiante -> {
            estudiante.setNombre(estudianteActualizado.getNombre());
            estudiante.setEdad(estudianteActualizado.getEdad());
        });
    }

    /**
     * Elimina un estudiante de la lista por su ID.
     * @param id Identificador del estudiante a eliminar.
     * @return true si fue eliminado; false si no se encontró.
     */
    public boolean eliminarPorId(int id) {
        return estudiantes.removeIf(e -> e.getId() == id);
    }
}

package ec.edu.espe.datos.model;

/**
 * Clase que representa a un estudiante.
 * Contiene los atributos básicos de un estudiante como ID, nombre y edad.
 * Se proporcionan métodos para acceder y modificar estos atributos,
 * así como un método para mostrar la información del estudiante como cadena de texto.
 */
public class Estudiante {
    private int id;
    private String nombre;
    private int edad;

    /**
     * Constructor vacío requerido para instanciación sin parámetros.
     */
    public Estudiante() {
    }

    /**
     * Constructor con parámetros para inicializar un estudiante.
     * @param id Identificador único del estudiante.
     * @param nombre Nombre del estudiante.
     * @param edad Edad del estudiante.
     */
    public Estudiante(int id, String nombre, int edad) {
        this.id = id;
        this.nombre = nombre;
        this.edad = edad;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    /**
     * Devuelve la representación textual del objeto estudiante.
     * @return Una cadena con los atributos del estudiante.
     */
    @Override
    public String toString() {
        return "Estudiante{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", edad=" + edad +
                '}';
    }
}

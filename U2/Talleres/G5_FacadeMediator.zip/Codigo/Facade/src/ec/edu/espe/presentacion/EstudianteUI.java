package ec.edu.espe.presentacion;

import ec.edu.espe.datos.model.Estudiante;
import ec.edu.espe.facade.EstudianteFacade;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 * Interfaz gráfica para gestionar estudiantes usando facade.
 * Permite crear, ver, actualizar y eliminar registros.
 */
public class EstudianteUI extends JFrame {
    private final EstudianteFacade estudianteFacade;

    private final JTextField txtId = new JTextField(5);
    private final JTextField txtNombre = new JTextField(10);
    private final JTextField txtEdad = new JTextField(5);

    private final DefaultTableModel tableModel = new DefaultTableModel(new Object[]{"ID", "Nombre", "Edad"}, 0);
    private final JTable tablaEstudiantes = new JTable(tableModel);

    /**
     * Constructor que configura la ventana y sus componentes.
     */
    public EstudianteUI() {
        estudianteFacade = new EstudianteFacade();

        setTitle("Gestión de Estudiantes");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panelCampos = new JPanel();
        panelCampos.add(new JLabel("ID:"));
        panelCampos.add(txtId);
        panelCampos.add(new JLabel("Nombre:"));
        panelCampos.add(txtNombre);
        panelCampos.add(new JLabel("Edad:"));
        panelCampos.add(txtEdad);

        JButton btnCrear = new JButton("Crear");
        JButton btnActualizar = new JButton("Actualizar");
        JButton btnEliminar = new JButton("Eliminar");
        JButton btnVerTodo = new JButton("Ver Todo");

        btnCrear.addActionListener(e -> crearEstudiante());
        btnActualizar.addActionListener(e -> actualizarEstudiante());
        btnEliminar.addActionListener(e -> eliminarEstudiante());
        btnVerTodo.addActionListener(e -> mostrarEstudiantes());

        JPanel panelBotones = new JPanel();
        panelBotones.add(btnCrear);
        panelBotones.add(btnActualizar);
        panelBotones.add(btnEliminar);
        panelBotones.add(btnVerTodo);

        JScrollPane scrollPane = new JScrollPane(tablaEstudiantes);

        setLayout(new BorderLayout());
        add(panelCampos, BorderLayout.NORTH);
        add(panelBotones, BorderLayout.CENTER);
        add(scrollPane, BorderLayout.SOUTH);
    }

    /**
     * Lógica para crear un nuevo estudiante desde la UI.
     */
    private void crearEstudiante() {
        int id = Integer.parseInt(txtId.getText());
        String nombre = txtNombre.getText();
        int edad = Integer.parseInt(txtEdad.getText());
        estudianteFacade.agregarEstudiante(id, nombre, edad);
        limpiarCampos();
        mostrarEstudiantes();
    }

    /**
     * Lógica para actualizar un estudiante.
     */
    private void actualizarEstudiante() {
        int id = Integer.parseInt(txtId.getText());
        String nombre = txtNombre.getText();
        int edad = Integer.parseInt(txtEdad.getText());
        estudianteFacade.actualizarEstudiante(id, nombre, edad);
        limpiarCampos();
        mostrarEstudiantes();
    }

    /**
     * Lógica para eliminar un estudiante por ID.
     */
    private void eliminarEstudiante() {
        int id = Integer.parseInt(txtId.getText());
        estudianteFacade.eliminarEstudiante(id);
        limpiarCampos();
        mostrarEstudiantes();
    }

    /**
     * Muestra todos los estudiantes en la tabla.
     */
    private void mostrarEstudiantes() {
        tableModel.setRowCount(0);
        List<Estudiante> estudiantes = estudianteFacade.obtenerTodosEstudiantes();
        for (Estudiante est : estudiantes) {
            tableModel.addRow(new Object[]{est.getId(), est.getNombre(), est.getEdad()});
        }
    }

    /**
     * Limpia los campos de entrada.
     */
    private void limpiarCampos() {
        txtId.setText("");
        txtNombre.setText("");
        txtEdad.setText("");
    }
}

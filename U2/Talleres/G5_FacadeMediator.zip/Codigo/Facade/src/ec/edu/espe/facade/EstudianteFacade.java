package ec.edu.espe.facade;

import ec.edu.espe.datos.model.Estudiante;
import ec.edu.espe.logica_negocio.EstudianteService;

import java.util.List;

/**
 * Facade proporciona una interfaz simplificada para gestionar estudiantes.
 * Encapsula la lógica de negocio y oculta los detalles del servicio.
 */
public class EstudianteFacade {
    private final EstudianteService estudianteService;

    /**
     * Constructor que inicializa el servicio de estudiantes.
     */
    public EstudianteFacade() {
        this.estudianteService = new EstudianteService();
    }

    /**
     * Agrega un nuevo estudiante.
     * @param id ID del estudiante.
     * @param nombre Nombre del estudiante.
     * @param edad Edad del estudiante.
     */
    public void agregarEstudiante(int id, String nombre, int edad) {
        estudianteService.crearEstudiante(id, nombre, edad);
    }

    /**
     * Obtiene la lista de todos los estudiantes.
     * @return Lista de estudiantes.
     */
    public List<Estudiante> obtenerTodosEstudiantes() {
        return estudianteService.obtenerTodos();
    }

    /**
     * Busca un estudiante por ID.
     * @param id ID del estudiante.
     * @return Objeto Estudiante o null si no se encuentra.
     */
    public Estudiante buscarEstudiantePorId(int id) {
        return estudianteService.buscarPorId(id);
    }

    /**
     * Actualiza los datos de un estudiante.
     * @param id ID del estudiante.
     * @param nuevoNombre Nuevo nombre.
     * @param nuevaEdad Nueva edad.
     */
    public void actualizarEstudiante(int id, String nuevoNombre, int nuevaEdad) {
        estudianteService.actualizarEstudiante(id, nuevoNombre, nuevaEdad);
    }

    /**
     * Elimina un estudiante por su ID.
     * @param id ID del estudiante.
     */
    public void eliminarEstudiante(int id) {
        estudianteService.eliminarEstudiante(id);
    }
}

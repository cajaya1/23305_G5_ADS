package ec.edu.espe.logica_negocio; // Define el paquete para la capa de lógica de negocio.

// Importación de las clases necesarias.
import ec.edu.espe.datos.model.Estudiante;
import ec.edu.espe.datos.repository.EstudianteRepository;
import java.util.List;

// Clase que representa el servicio de estudiantes.
// Esta clase actúa como intermediaria entre el controlador (interfaz de usuario o API) y el repositorio (datos).
public class EstudianteService {

    // Atributo privado que referencia al repositorio de estudiantes.
    private EstudianteRepository estudianteRepository;

    // Constructor que instancia el repositorio.
    public EstudianteService() {
        estudianteRepository = new EstudianteRepository();
    }

    // Método para agregar un nuevo estudiante usando datos individuales.
    // Crea un objeto Estudiante y lo pasa al repositorio para su almacenamiento.
    public void agregarEstudiante(int id, String nombre, int edad) {
        Estudiante estudiante = new Estudiante(id, nombre, edad);
        estudianteRepository.agregarEstudiante(estudiante);
    }

    // Método que devuelve la lista completa de estudiantes.
    public List<Estudiante> obtenerEstudiantes() {
        return estudianteRepository.obtenerEstudiantes();
    }

    // Método que devuelve un estudiante específico según su ID.
    public Estudiante obtenerEstudiantePorId(int id) {
        return estudianteRepository.obtenerEstudiantePorId(id);
    }

    // Método para actualizar los datos de un estudiante.
    // Crea un objeto Estudiante con los nuevos valores y lo pasa al repositorio.
    public void actualizarEstudiante(int id, String nombre, int edad) {
        Estudiante estudiante = new Estudiante(id, nombre, edad);
        estudianteRepository.actualizarEstudiante(estudiante);
    }

    // Método para eliminar un estudiante del sistema usando su ID.
    public void eliminarEstudiante(int id) {
        estudianteRepository.eliminarEstudiante(id);
    }
}

package ec.edu.espe.mediator;

import ec.edu.espe.datos.model.Estudiante;
import ec.edu.espe.logica_negocio.EstudianteService;

import java.util.List;

public class EstudianteMediatorImpl implements EstudianteMediator {

    private EstudianteService estudianteService;

    public EstudianteMediatorImpl() {
        estudianteService = new EstudianteService();
    }

    @Override
    public void crearEstudiante(int id, String nombre, int edad) {
        estudianteService.agregarEstudiante(id, nombre, edad);
    }

    @Override
    public void actualizarEstudiante(int id, String nombre, int edad) {
        estudianteService.actualizarEstudiante(id, nombre, edad);
    }

    @Override
    public void eliminarEstudiante(int id) {
        estudianteService.eliminarEstudiante(id);
    }

    @Override
    public Estudiante obtenerEstudiante(int id) {
        return estudianteService.obtenerEstudiantePorId(id);
    }

    @Override
    public List<Estudiante> obtenerTodosEstudiantes() {
        return estudianteService.obtenerEstudiantes();
    }
}

package ec.edu.espe; // Paquete raíz de la aplicación.

/**
 * Clase principal que sirve como punto de entrada del programa.
 * Inicia la interfaz gráfica de usuario para la gestión de estudiantes.
 */
import ec.edu.espe.presentacion.EstudianteUI;

public class Main {

    // Método main: el punto de inicio de ejecución de la aplicación.
    public static void main(String[] args) {
        // Crea una instancia de la interfaz gráfica.
        EstudianteUI estudianteUI = new EstudianteUI();

        // Hace visible la ventana para que el usuario pueda interactuar.
        estudianteUI.setVisible(true);
    }
}

package ec.edu.espe.presentacion; // Paquete donde se ubica la capa de presentación (interfaz gráfica).

import ec.edu.espe.datos.model.Estudiante;
import ec.edu.espe.mediator.EstudianteMediatorImpl;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 * Clase que define la interfaz gráfica (GUI) para la gestión de estudiantes.
 * Utiliza Swing y sigue el patrón MVC, donde esta clase representa la "Vista" que interactúa con el "Mediador".
 */
public class EstudianteUI extends JFrame {

    // Instancia del mediador para acceder a las operaciones de negocio.
    private EstudianteMediatorImpl mediator;

    // Componentes de la interfaz.
    private JTextField txtId, txtNombre, txtEdad;
    private JButton btnCrear, btnVer, btnActualizar;
    private JTable tablaEstudiantes;
    private DefaultTableModel tableModel;

    // Constructor que configura toda la ventana.
    public EstudianteUI() {
        setTitle("Gestión de Estudiantes");               // Título de la ventana.
        setSize(600, 500);                                // Tamaño de la ventana.
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);   // Cierra el programa al cerrar ventana.
        setLocationRelativeTo(null);                      // Centra la ventana en la pantalla.
        setLayout(new BorderLayout(10, 10));              // Layout general.

        mediator = new EstudianteMediatorImpl();          // Inicializa el mediador.

        // Panel de entrada de datos
        JPanel panelCampos = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5); // Espaciado entre componentes

        // Campo ID
        gbc.gridx = 0; gbc.gridy = 0;
        panelCampos.add(new JLabel("ID:"), gbc);
        gbc.gridx = 1;
        txtId = new JTextField(20);
        panelCampos.add(txtId, gbc);

        // Campo Nombre
        gbc.gridx = 0; gbc.gridy = 1;
        panelCampos.add(new JLabel("Nombre:"), gbc);
        gbc.gridx = 1;
        txtNombre = new JTextField(20);
        panelCampos.add(txtNombre, gbc);

        // Campo Edad
        gbc.gridx = 0; gbc.gridy = 2;
        panelCampos.add(new JLabel("Edad:"), gbc);
        gbc.gridx = 1;
        txtEdad = new JTextField(20);
        panelCampos.add(txtEdad, gbc);

        // Panel con botones de acciones
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        btnCrear = new JButton("Crear Estudiante");
        btnVer = new JButton("Ver Todos");
        btnActualizar = new JButton("Actualizar");
        panelBotones.add(btnCrear);
        panelBotones.add(btnVer);
        panelBotones.add(btnActualizar);

        // Agrupa campos y botones
        JPanel panelPrincipal = new JPanel(new BorderLayout());
        panelPrincipal.add(panelCampos, BorderLayout.NORTH);
        panelPrincipal.add(panelBotones, BorderLayout.CENTER);
        add(panelPrincipal, BorderLayout.NORTH);

        // Tabla para mostrar estudiantes
        String[] columnNames = {"ID", "Nombre", "Edad"};
        tableModel = new DefaultTableModel(columnNames, 0);
        tablaEstudiantes = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(tablaEstudiantes);
        add(scrollPane, BorderLayout.CENTER);

        // Acciones de los botones
        btnCrear.addActionListener(e -> crearEstudiante());
        btnVer.addActionListener(e -> verEstudiantes());
        btnActualizar.addActionListener(e -> actualizarEstudiante());
    }

    // Método que permite crear un nuevo estudiante o reemplazar uno existente con el mismo ID
    private void crearEstudiante() {
        try {
            int id = Integer.parseInt(txtId.getText());
            String nombre = txtNombre.getText();
            int edad = Integer.parseInt(txtEdad.getText());

            Estudiante existente = mediator.obtenerEstudiante(id);
            if (existente != null) {
                mediator.eliminarEstudiante(id); // Elimina si ya existe uno con el mismo ID
                JOptionPane.showMessageDialog(this, "Estudiante existente eliminado.");
            } else {
                JOptionPane.showMessageDialog(this, "No existe un estudiante con ese ID para eliminar.");
            }

            mediator.crearEstudiante(id, nombre, edad); // Crea el nuevo
            JOptionPane.showMessageDialog(this, "Estudiante creado con éxito");
            limpiarCampos();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Por favor, ingresa datos válidos.");
        }
    }

    // Muestra todos los estudiantes registrados en la tabla
    private void verEstudiantes() {
        List<Estudiante> estudiantes = mediator.obtenerTodosEstudiantes();
        tableModel.setRowCount(0); // Limpia la tabla antes de agregar nuevos datos

        for (Estudiante estudiante : estudiantes) {
            tableModel.addRow(new Object[]{estudiante.getId(), estudiante.getNombre(), estudiante.getEdad()});
        }
    }

    // Actualiza un estudiante con los datos ingresados
    private void actualizarEstudiante() {
        try {
            int id = Integer.parseInt(txtId.getText());
            String nombre = txtNombre.getText();
            int edad = Integer.parseInt(txtEdad.getText());

            mediator.actualizarEstudiante(id, nombre, edad);
            JOptionPane.showMessageDialog(this, "Estudiante actualizado con éxito");
            limpiarCampos();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Por favor, ingresa datos válidos.");
        }
    }

    // Limpia los campos de entrada
    private void limpiarCampos() {
        txtId.setText("");
        txtNombre.setText("");
        txtEdad.setText("");
    }

    // Método principal para ejecutar la aplicación
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            EstudianteUI ui = new EstudianteUI(); // Crea una instancia de la UI
            ui.setVisible(true);                 // Muestra la ventana
        });
    }
}

package ec.edu.espe.datos.repository; // Define el paquete al que pertenece esta clase.

// Importación de la clase Estudiante y utilidades de listas.
import ec.edu.espe.datos.model.Estudiante;
import java.util.ArrayList;
import java.util.List;

// Clase que simula un repositorio de estudiantes (almacenamiento en memoria).
public class EstudianteRepository {

    // Lista que almacena los objetos Estudiante.
    private List<Estudiante> estudiantes;

    // Constructor que inicializa la lista vacía de estudiantes.
    public EstudianteRepository() {
        estudiantes = new ArrayList<>();
    }

    // Método para agregar un nuevo estudiante a la lista.
    public void agregarEstudiante(Estudiante estudiante) {
        estudiantes.add(estudiante);
    }

    // Método para obtener la lista completa de estudiantes.
    public List<Estudiante> obtenerEstudiantes() {
        return estudiantes;
    }

    // Método para buscar un estudiante por su ID.
    // Si lo encuentra, lo devuelve; si no, retorna null.
    public Estudiante obtenerEstudiantePorId(int id) {
        for (Estudiante estudiante : estudiantes) {
            if (estudiante.getId() == id) {
                return estudiante;
            }
        }
        return null;
    }

    // Método para actualizar los datos de un estudiante existente.
    // Se busca por ID y se actualizan su nombre y edad si existe.
    public void actualizarEstudiante(Estudiante estudiante) {
        Estudiante estudianteExistente = obtenerEstudiantePorId(estudiante.getId());
        if (estudianteExistente != null) {
            estudianteExistente.setNombre(estudiante.getNombre());
            estudianteExistente.setEdad(estudiante.getEdad());
        }
    }

    // Método para eliminar un estudiante por su ID.
    // Si el estudiante existe, se elimina de la lista.
    public void eliminarEstudiante(int id) {
        Estudiante estudiante = obtenerEstudiantePorId(id);
        if (estudiante != null) {
            estudiantes.remove(estudiante);
        }
    }
}

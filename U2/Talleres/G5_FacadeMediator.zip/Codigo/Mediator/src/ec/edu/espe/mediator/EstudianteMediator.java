package ec.edu.espe.mediator; // Paquete que representa la capa de mediación o coordinación.

// Importación de la clase Estudiante y la utilidad List.
import ec.edu.espe.datos.model.Estudiante;
import java.util.List;

/**
 * Interfaz que define las operaciones que se pueden realizar sobre los estudiantes.
 * Actúa como un punto de acceso unificado o fachada para coordinar la lógica de negocio.
 * Puede facilitar desacoplamiento entre la presentación (UI/API) y la lógica interna.
 */
public interface EstudianteMediator {

    // Método para crear un nuevo estudiante.
    void crearEstudiante(int id, String nombre, int edad);

    // Método para actualizar los datos de un estudiante existente.
    void actualizarEstudiante(int id, String nombre, int edad);

    // Método para eliminar un estudiante según su ID.
    void eliminarEstudiante(int id);

    // Método para obtener un estudiante específico por ID.
    Estudiante obtenerEstudiante(int id);

    // Método para obtener la lista de todos los estudiantes registrados.
    List<Estudiante> obtenerTodosEstudiantes();
}

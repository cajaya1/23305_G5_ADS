package ec.edu.espe.datos.model; // Define el paquete al que pertenece esta clase (estructura del proyecto).

// Clase que representa a un estudiante con sus atributos básicos.
public class Estudiante {

    // Atributos privados del estudiante (encapsulamiento).
    private int id;        // Identificador único del estudiante.
    private String nombre; // Nombre del estudiante.
    private int edad;      // Edad del estudiante.

    // Constructor de la clase Estudiante.
    // Permite crear un objeto Estudiante con un id, nombre y edad específicos.
    public Estudiante(int id, String nombre, int edad) {
        this.id = id;
        this.nombre = nombre;
        this.edad = edad;
    }

    // Métodos getter y setter para el atributo 'id'.
    // Permiten obtener y modificar el valor del id de forma controlada.
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    // Métodos getter y setter para el atributo 'nombre'.
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    // Métodos getter y setter para el atributo 'edad'.
    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    // Método toString sobrescrito.
    // Devuelve una representación en texto del objeto Estudiante.
    // Útil para imprimir la información del estudiante de forma legible.
    @Override
    public String toString() {
        return "ID: " + id + ", Nombre: " + nombre + ", Edad: " + edad;
    }
}
